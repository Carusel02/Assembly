README
1) la task1 m am gandit sa folosesc un vector de masca pentru a afla
de fiecare data cate un minim, legand elementele intre ele

2) la task2 am folosit stiva -> la part1 trebuia sa folosesti mul si 
div pt cmmmc si la part2 trebuia sa numeri nr de paranteze

3) la task3 trebuia sa folosesti mai multe functii si sa pushezi pe stiva
parametrii

4) la task4 trebuia sa pui in eax niste valori si sa apelezi comanda cpuid

bonus sintaxa at&t) la fel ca cea normala, se schimba doar ordinea operanzilor

Detaliile amanuntite sunt lasate in cod (comentarii)
